-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k6e1021.p.ssafy.io    Database: modong
-- ------------------------------------------------------
-- Server version	5.7.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `age` int(11) NOT NULL,
  `banned` bit(1) NOT NULL,
  `date_create` datetime(6) DEFAULT NULL,
  `date_withdraw` datetime(6) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_pw_en` varchar(255) NOT NULL,
  `dongcode` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6efs5vmce86ymf5q7lmvn2uuf` (`user_id`),
  UNIQUE KEY `UK_81dnnwu0i3ls0d89gheu8gq1d` (`user_pw_en`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,0,_binary '\0','2022-05-18 10:28:14.869684',NULL,_binary '\0','https://s3.ap-northeast-2.amazonaws.com/modong-bucket/c0a94c11ac32482187fbfcb2389b7974.webp',NULL,'인수','01045344466','ygc8257@naver.com','$2a$10$TixHgq47FkwSB5wilj1UWepPfG7L0AaFzNQ5/Y1Bv7kGj84d5pgyK',2641010700),(2,0,_binary '\0','2022-05-18 10:51:10.591398',NULL,_binary '\0','https://s3.ap-northeast-2.amazonaws.com/modong-bucket/ab93c6e5eb7543c6b307fc1495d20c9c.webp',NULL,'인수2','01045344464','asd1234@nsnsn.com','$2a$10$ZyS3CO2qZfPeA0T5lbYjkO18qVtDBRElTEzMHOeScNDRHs1vmr6nS',2641010700),(3,0,_binary '\0','2022-05-18 13:11:38.769676',NULL,_binary '\0','https://s3.ap-northeast-2.amazonaws.com/modong-bucket/366f5c0dc21e4ee48b7b655ef6af582c.jpg',NULL,'개구리','01000000000','b@b.com','$2a$10$EtoGr2t/bAHEyVgy2CcV4eWU2dpirZ5izc4HI4fac1PAVBuy.SUu6',2611010100),(8,0,_binary '\0','2022-05-20 02:18:11.525244',NULL,_binary '\0','https://s3.ap-northeast-2.amazonaws.com/modong-bucket/0860dbf234aa4ab588d2da92eac747a0.png',NULL,'SSAFY','01062689485','winckey0@naver.com','$2a$10$K.1/xr4m1Tlng8FYzX3YheASOm2BCAORy42Cpq1p5SqSA.TlkmzsG',2611010100),(10,0,_binary '\0','2022-05-20 08:53:09.794201',NULL,_binary '\0',NULL,NULL,'김싸피','01062689485','test@test.com','$2a$10$kooXT6MfF2bwDmD6iW7pH.YOv0XXaSki9TNbTHii0FvE0SPQvWCsq',2611010100),(12,0,_binary '\0','2022-05-20 09:02:09.735941',NULL,_binary '\0','https://s3.ap-northeast-2.amazonaws.com/modong-bucket/946e78c231be4eca9503f52871e041f7.jpg',NULL,'맛집탐방','01062689485','winckey3@naver.com','$2a$10$PlRZKBM.TmEm0a8RI8Hx..WblhT.RJhlmOWYcF1ZIg6xfLzV5SoWq',2611010100),(13,0,_binary '\0','2022-05-20 09:06:19.768022',NULL,_binary '\0',NULL,NULL,'모여봐요','01062689485','b1@b1.com','$2a$10$5/6NdwmoLpNUY00czBBxKOYYAVzLfp7PVkrZuoZnZ00XFxkHGjNuO',2611010100);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20  9:46:30
